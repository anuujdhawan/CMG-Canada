# Study Permit Application - Document Checklist 2026

> **Source URL:** https://visamastercanada.com/resources/document-checklist/study-permit
> **Last modified:** 2026-08-13T16:43:55.760Z
> **Sitemap priority:** 0.8
> **Status:** ✅ Unique English content (processed)

---

## SEO Metadata

- **Title tag:** Study Permit Application - Document Checklist 2026
- **Meta description:** Complete document checklist for Canadian study permit applications. Includes SDS (Student Direct Stream) and regular stream documents, with licensed RCIC tips.
- **Meta keywords:** (none)
- **Canonical URL:** https://visamastercanada.com/resources/document-checklist/study-permit
- **OG title:** Study Permit Application - Document Checklist 2026
- **OG description:** Complete document checklist for Canadian study permit applications. Includes SDS (Student Direct Stream) and regular stream documents, with licensed RCIC tips.
- **Robots:** index, follow

## Heading Outline

- # Study Permit Application - Document Checklist 2026
- ## 1 Acceptance & School Documents
- ## 2 Identity Documents
- ## 3 Proof of Financial Support
- ## 4 Academic Documents
- ## 5 Ties to Home Country
- ## 💡 RCIC Pro Tips
- ## Frequently Asked Questions
- ### Can I work in Canada with a study permit?
- ### What is the difference between SDS and the regular study permit stream?
- ## Ready to start your Study Permit application?

---

## Hero Section

# Study Permit Application - Document Checklist 2026

Canada receives hundreds of thousands of study permit applications every year, and the difference between approval and refusal is almost always documentation - particularly proof of financial support and evidence of ties to your home country. This checklist covers everything you need for both the regular stream and the faster Student Direct Stream (SDS), with the practical notes our licensed RCICs give their own clients.

---

## Page Content


## 1 Acceptance & School Documents

Must show: full name, program name, start/end date, language of instruction, DLI number

Check at canada.ca/dli-list

Required for most post-secondary students since January 2024 (not required for certain categories)

## 2 Identity Documents

Must be valid for the entire duration of your study program plus 6 months

## 3 Proof of Financial Support

Must show sufficient funds: tuition + CAD $10,000 living costs per year (more in high-cost cities)

Include relationship document (e.g., birth certificate) if sponsor is a family member

Required for Student Direct Stream applicants. Must be from approved financial institution.

Receipt showing you have paid or are scheduled to pay first semester tuition

## 4 Academic Documents

Official transcripts from secondary school or post-secondary institutions

Required for SDS. Strongly recommended for regular stream. Minimum IELTS 6.0 for SDS.

## 5 Ties to Home Country

A 1-2 page letter explaining: why you chose this program, how it relates to your career goals, and why you plan to return to your home country after graduation. This is critical for visa officers assessing your intent.

Shows established career and economic ties to home country

Marriage certificate, dependent children - evidence you have compelling reasons to return

## 💡 RCIC Pro Tips

- 1 . The study plan / statement of purpose is the most important document in a study permit application - it must clearly explain why you chose Canada, this specific school, and this program, AND why you will return home after graduation.
- 2 . Apply as early as possible - ideally 4-6 months before your program start date. Processing times for high-volume countries (India, Nigeria, China) can exceed 12 weeks.
- 3 . The Provincial Attestation Letter (PAL) is a new requirement as of January 2024. Confirm your school has applied for and received a PAL allocation before you apply.
- 4 . SDS (Student Direct Stream) is significantly faster (~20 days) if you qualify - it requires IELTS 6.0+, a GIC of $20,635+, and a PAL from a participating province.
- 5 . Ensure your bank statements show the funds have been present for at least 3-4 months - a sudden large deposit right before the application raises red flags.

## Frequently Asked Questions

### Can I work in Canada with a study permit?

Yes. Full-time students at eligible DLIs can work up to 24 hours per week off-campus during the academic session, and full-time during scheduled breaks. You may also be eligible for on-campus work without restriction.

### What is the difference between SDS and the regular study permit stream?

Student Direct Stream (SDS) is a faster processing track (~20 days) for applicants from India, China, Philippines, Vietnam, Morocco, and several other countries. Requirements include IELTS 6.0+, a GIC of $20,635, a PAL, and upfront medical exam. Regular stream has no language test minimum but takes 8-16 weeks.

This checklist was prepared by licensed RCICs at VMC Immigration Services and is updated regularly. It is for informational purposes only. Always verify current requirements at ircc.canada.ca. Individual circumstances vary - consult a licensed RCIC for advice specific to your case.

## Ready to start your Study Permit application?

Our licensed RCICs have helped thousands of clients get approved. Book a free consultation to discuss your specific situation and get a personalized action plan.

Also see: All checklists · Processing times · Express Entry draws
---

## Links & CTAs on this page


| Anchor text | URL |
| --- | --- |
| Skip to main content | https://visamastercanada.com/resources/document-checklist/study-permit#main-content |
| Make Payment | https://visamastercanada.com/pay |
| Book Book Consultation | https://visamastercanada.com/book |
| Learn more about Study Permit → | https://visamastercanada.com/immigration/study-permit |
| View IRCC Processing Times → | https://visamastercanada.com/resources/processing-times |
| 📅 Book Free Consultation | https://visamastercanada.com/book |
| All checklists | https://visamastercanada.com/resources/document-checklist |
| Processing times | https://visamastercanada.com/resources/processing-times |
| Express Entry draws | https://visamastercanada.com/draw-results |
---

## Image Alt Texts


- Licensed Regulated Canadian Immigration Consultants - Brampton, GTA & Canada-wide
---

## Structured Data (JSON-LD)

```json
{"@context":"https://schema.org","@type":"ProfessionalService","name":"VMC Immigration Services","alternateName":["Visa Master Canada","Visa Master Can","VMC"],"legalName":"VMC Immigration Services","description":"CICC-regulated immigration consulting firm. Licensed RCICs specializing in Express Entry, all PNP streams, LMIA, work permits, study permits, spousal sponsorship, refusals, and citizenship. Serving all of Canada from our Brampton, Ontario office.","founder":{"@type":"Person","name":"Sanjay Singh Kumar","jobTitle":"Regulated Canadian Immigration Consultant (RCIC)","identifier":"RCIC R705959","memberOf":{"@type":"Organization","name":"College of Immigration and Citizenship Consultants (CICC)"}},"url":"https://visamastercanada.com","logo":{"@type":"ImageObject","url":"https://visamastercanada.com/logos/vmc-logo.svg"},"image":"https://visamastercanada.com/opengraph-image","telephone":"+16473953471","email":"info@visamastercanada.com","priceRange":"$$","currenciesAccepted":"CAD","paymentAccepted":"Credit Card, Debit Card, Bank Transfer","address":{"@type":"PostalAddress","streetAddress":"83 Kennedy Rd S Unit 16","addressLocality":"Brampton","addressRegion":"ON","postalCode":"L6W 3P3","addressCountry":"CA"},"geo":{"@type":"GeoCoordinates","latitude":43.6956,"longitude":-79.7596},"openingHoursSpecification":[{"@type":"OpeningHoursSpecification","dayOfWeek":["Monday","Tuesday","Wednesday","Thursday","Friday"],"opens":"09:00","closes":"18:00"},{"@type":"OpeningHoursSpecification","dayOfWeek":"Saturday","opens":"10:00","closes":"16:00"}],"areaServed":{"@type":"Country","name":"Canada"},"hasMap":"https://maps.google.com/?q=83+Kennedy+Rd+S,+Brampton,+ON","sameAs":["https://facebook.com/VisaMasterCan","https://linkedin.com/company/visamastercan","https://instagram.com/visamastercanada"],"serviceType":["Express Entry Immigration Consulting","Provincial Nominee Program (PNP) Consulting","Work Permit Application","Study Permit Application","Spousal Sponsorship","LMIA Processing","Visa Refusal Appeals","Citizenship Application","Super Visa Application"]}
```

```json
{"@context":"https://schema.org","@type":"FAQPage","mainEntity":[{"@type":"Question","name":"Can I work in Canada with a study permit?","acceptedAnswer":{"@type":"Answer","text":"Yes. Full-time students at eligible DLIs can work up to 24 hours per week off-campus during the academic session, and full-time during scheduled breaks. You may also be eligible for on-campus work without restriction."}},{"@type":"Question","name":"What is the difference between SDS and the regular study permit stream?","acceptedAnswer":{"@type":"Answer","text":"Student Direct Stream (SDS) is a faster processing track (~20 days) for applicants from India, China, Philippines, Vietnam, Morocco, and several other countries. Requirements include IELTS 6.0+, a GIC of $20,635, a PAL, and upfront medical exam. Regular stream has no language test minimum but takes 8-16 weeks."}}]}
```

```json
{"@context":"https://schema.org","@type":"BreadcrumbList","itemListElement":[{"@type":"ListItem","position":1,"name":"Home","item":"https://visamastercanada.com"},{"@type":"ListItem","position":2,"name":"Resources","item":"https://visamastercanada.com/resources"},{"@type":"ListItem","position":3,"name":"Document Checklists","item":"https://visamastercanada.com/resources/document-checklist"},{"@type":"ListItem","position":4,"name":"Study Permit","item":"https://visamastercanada.com/resources/document-checklist/study-permit"}]}
```
