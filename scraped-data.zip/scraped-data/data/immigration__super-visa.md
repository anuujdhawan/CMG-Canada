# Canada Super Visa 2026 | Parents & Grandparents | 5-Year Stay | Licensed RCIC

> **Source URL:** https://visamastercanada.com/immigration/super-visa
> **Last modified:** 2026-08-13T16:43:55.760Z
> **Sitemap priority:** 0.8
> **Status:** ✅ Unique English content (processed)

---

## SEO Metadata

- **Title tag:** Canada Super Visa 2026 | Parents & Grandparents | 5-Year Stay | Licensed RCIC
- **Meta description:** Super Visa Canada for parents and grandparents: stays up to 5 years, valid 10 years. Licensed RCIC support from start to finish. Free eligibility check.
- **Meta keywords:** (none)
- **Canonical URL:** https://visamastercanada.com/immigration/super-visa
- **OG title:** Canada Super Visa 2026 | Licensed RCIC
- **OG description:** Super Visa Canada for parents and grandparents: stays up to 5 years, valid 10 years. Licensed RCIC support from start to finish. Free eligibility check.
- **Robots:** index, follow

## Heading Outline

- # Canada Super Visa 2026 - Let Your Parents and Grandparents Stay Up to 5 Years
- ## The Super Visa - Extended Family Visits
- ### Up to 5 Years Per Stay
- ### Valid for 10 Years
- ### For Parents & Grandparents Only
- ### Health Insurance Required
- ## Who Can Apply for a Super Visa?
- ### Applicant Requirements
- ### Host (Sponsor) Requirements
- ## Super Visa Document Checklist
- ### Applicant Documents
- ### Host Documents
- ## How to Apply for a Super Visa
- ### Confirm Host Meets LICO
- ### Purchase Health Insurance
- ### Gather All Documents
- ### Complete Application Online
- ### Provide Biometrics
- ### Receive Super Visa
- ### Host's income doesn't meet LICO?
- ## Super Visa vs Regular Visitor Visa - Which Is Better for Parents?
- ## Parents & Grandparents Program vs Super Visa
- ### Parents & Grandparents Program (PGP)
- ### Super Visa (Recommended for 2026)
- ## Why Families Choose VMC for Super Visa
- ### Licensed RCICs
- ### LICO Income Check
- ### Complete Documentation
- ### Family Specialists
- ### Canada-Wide
- ### Refusal Recovery
- ## Frequently Asked Questions
- ## Bring Your Parents to Canada - the Right Way
- ## Related Services

---

## Hero Section

# Canada Super Visa 2026 - Let Your Parents and Grandparents Stay Up to 5 Years

The Super Visa is the best option for parents and grandparents while the Parents and Grandparents Program remains closed in 2026. Stay up to 5 years per visit, valid 10 years.

Super Visa snapshot

5 yrs

Max stay / entry

10 yrs

Visa validity

$100K+

Insurance min.

LICO

Host income

Related

- → Visitor Visa (TRV)
- → PGP overview
- → Family sponsorship
Confirm LICO first

We verify host household size and income before you invest in insurance and fees. IRCC's official Super Visa page is the reference for the current rules.

---

## Page Content

## The Super Visa - Extended Family Visits

Introduced as an alternative to the PGP, the Super Visa lets parents and grandparents of Canadian citizens and PRs visit Canada for extended periods. Whether your parents are applying from India, Pakistan, Philippines, Sri Lanka, or anywhere else - the same rules apply and VMC prepares the full file.

### Up to 5 Years Per Stay

Since 2022, each Super Visa entry allows a stay of up to 5 years - far longer than the standard visitor visa (typically 6 months).

### Valid for 10 Years

The Super Visa itself is valid for up to 10 years (or until passport expiry), allowing multiple entries over a long period.

### For Parents & Grandparents Only

Only parents and grandparents of Canadian citizens or permanent residents qualify. Siblings, aunts, uncles, and other relatives do not qualify for Super Visa.

### Health Insurance Required

You must purchase a minimum $100,000 Canadian health insurance policy valid for at least 1 year from a Canadian insurer before the Super Visa can be issued.

## Who Can Apply for a Super Visa?

Both the applicant (parent/grandparent) and the Canadian host (child/grandchild) must meet eligibility requirements.

### Applicant Requirements

- Parent or grandparent of a Canadian citizen or permanent resident
- Not inadmissible to Canada (criminal, medical)
- Valid passport with sufficient validity
- Genuine intent to leave Canada at end of authorized stay
- $100K+ Canadian health insurance purchased before visa issuance
- Medical exam (if required by IRCC based on country of residence)
- Police certificate if requested by the visa officer

### Host (Sponsor) Requirements

- Canadian citizen or permanent resident
- Must be the child or grandchild of the applicant
- Must meet Minimum Necessary Income (LICO threshold - see below)
- Must sign a letter of invitation confirming full financial support
- Must provide proof of status (citizenship certificate, PR card, or Indian Status document)
- Must list all dependent children and adults living in the household
| Family Size |
| MNI 2026 (approx) |
| 1 person |
| $26,620 |
| 2 persons |
| $33,159 |
| 3 persons |
| $40,745 |
| 4 persons |
| $49,481 |
| 5 persons |
| $56,146 |
| 6 persons |
| $63,334 |
| 7+ persons |
| $70,523 |
LICO thresholds updated annually. Confirm current figures on IRCC. Super Visa uses the LICO table applicable to the host's household.

## Super Visa Document Checklist

Incomplete applications are the most common cause of delays. We review every document before submission.

### Applicant Documents

- Valid passport (6+ months beyond stay)
- Completed application forms
- Two passport-style photographs
- Proof of $100K+ Canadian health insurance
- Proof of funds (if applicable)
- Medical exam results (if required)
- Biometrics

### Host Documents

- Letter of invitation from child/grandchild
- Proof of Canadian citizenship or PR status
- Proof of relationship to applicant
- Proof of income meeting LICO threshold (T4, NOA, pay stubs, employment letter)
- Proof of household size
- Any additional documents requested by the officer
Health Insurance Requirements 2026:

Minimum $100,000 coverage · From a Canadian insurance company · Valid for at least 1 year from date of entry · Must be purchased BEFORE the visa is issued

## How to Apply for a Super Visa

### Confirm Host Meets LICO

Check the current LICO threshold for the host's household size. This is the most common eligibility blocker.

### Purchase Health Insurance

Buy minimum $100K Canadian health insurance BEFORE applying. Get the insurance certificate - you will need it with the application.

### Gather All Documents

Passport, photos, invitation letter, host's income proof, relationship proof, and medical exam (if required).

### Complete Application Online

Submit through IRCC's online portal with all documents. Both parent and host contribute documents to the file.

### Provide Biometrics

Visit a Visa Application Centre (VAC) to provide fingerprints and photograph (if first application or renewal required).

### Receive Super Visa

Processing typically 4-8 weeks. Once approved, the Super Visa is stamped in the passport. Entry can be made within the validity period.

Super Visa Application Fees 2026:

Processing fee: CAD $100 · Biometrics: CAD $85 (if required). These fees are identical to a regular visitor visa application. Government fees are separate from VMC's professional service fees.

### Host's income doesn't meet LICO?

A co-signer (another Canadian child or grandchild of the applicant) can co-sign the invitation letter and combine household income to meet the LICO threshold. VMC advises on the correct documentation.

## Super Visa vs Regular Visitor Visa - Which Is Better for Parents?

| Feature |
| Super Visa |
| Regular TRV |
| Stay per entry |
| Up to 5 years |
| Typically 6 months |
| Visa validity |
| Up to 10 years |
| Up to 10 years |
| Who qualifies |
| Parents/grandparents of Cdn citizens/PRs |
| Anyone eligible for TRV |
| Health insurance |
| $100K+ required |
| Not required |
| LICO income check |
| Yes - host must meet LICO |
| No |
| Processing time |
| 4-8 weeks |
| 2-6 weeks |
| Extension possible |
| Yes - from inside Canada |
| Yes - visitor record |
| Best for |
| Long stays · living with family |
| Short visits · tourism |
For parents and grandparents planning to stay more than 6 months or make multiple long visits - the Super Visa is almost always the better choice. The insurance cost is offset by the much longer stay per entry and fewer applications needed.

## Parents & Grandparents Program vs Super Visa

PGP is closed to new applications in 2026. Here's how the two options compare.

### Parents & Grandparents Program (PGP)

PGP grants permanent residence to parents and grandparents. Not accepting new applications in 2026. Past invitees' files continue processing.

- - Result: Permanent Residence
- - Status: Closed to new apps 2026
- - Processing: Multi-year for new files
- - Income: LICO+30% for 3 years
- - Quota: 66,500 total (2026)

### Super Visa (Recommended for 2026)

Super Visa grants temporary status up to 5 years per entry - the practical solution while PGP remains closed.

- - Result: Temporary Status
- - Status: Open - apply anytime
- - Processing: 4-8 weeks
- - Income: LICO for host
- - Multiple entries over 10 years

## Why Families Choose VMC for Super Visa

### Licensed RCICs

Regulated family class and visitor application specialists. Check the CICC register to confirm any licence.

### LICO Income Check

We verify host income meets LICO before applying - avoiding the most common refusal reason.

### Complete Documentation

Invitation letters, income proof, insurance coordination - all reviewed before submission.

### Family Specialists

1,000+ family cases including Super Visa, PGP, and family class sponsorship.

### Canada-Wide

Serving families in Brampton · Toronto · Mississauga · GTA and every province - in person or virtual.

### Refusal Recovery

Super Visa refused? We review the refusal and build a stronger reapplication.

## Frequently Asked Questions

## Bring Your Parents to Canada - the Right Way

We handle the complete Super Visa application - health insurance guidance, LICO verification, invitation letter, and full IRCC submission.

Serving families in Brampton · Toronto · Mississauga · Ontario and across Canada - plus parents applying from India, Pakistan, Philippines, Sri Lanka, and worldwide.

## Related Services

---

## Links & CTAs on this page

| Anchor text | URL |
| --- | --- |
| Skip to main content | https://visamastercanada.com/immigration/super-visa#main-content |
| Make Payment | https://visamastercanada.com/pay |
| Book Book Consultation | https://visamastercanada.com/book |
| Home | https://visamastercanada.com/ |
| Immigration | https://visamastercanada.com/immigration |
| Book Free Consultation → | https://visamastercanada.com/book |
| Check My Eligibility | https://visamastercanada.com/tools |
| (647) 395-3471 | tel:+16473953471 |
| → Visitor Visa (TRV) | https://visamastercanada.com/immigration/visitor-visa |
| → PGP overview | https://visamastercanada.com/immigration/pgp |
| → Family sponsorship | https://visamastercanada.com/immigration/family-sponsorship |
| Book assessment → | https://visamastercanada.com/book |
| Book Free Assessment → | https://visamastercanada.com/book |
| Call (647) 395-3471 | tel:+16473953471 |
| PGP information → | https://visamastercanada.com/immigration/pgp |
| Apply for Super Visa → | https://visamastercanada.com/contact-us |
| Use Free Tools | https://visamastercanada.com/tools |
| Visitor Visa (TRV) → | https://visamastercanada.com/immigration/visitor-visa |
| eTA → | https://visamastercanada.com/immigration/eta |
| Family Sponsorship → | https://visamastercanada.com/immigration/family-sponsorship |
| PGP Info → | https://visamastercanada.com/immigration/pgp |
| Visitor Record → | https://visamastercanada.com/immigration/visitor-record |
| Refusals & PFL → | https://visamastercanada.com/refusals |

---

## Image Alt Texts

- Licensed Regulated Canadian Immigration Consultants - Brampton, GTA & Canada-wide

---

## Structured Data (JSON-LD)

```json
{"@context":"https://schema.org","@type":"ProfessionalService","name":"VMC Immigration Services","alternateName":["Visa Master Canada","Visa Master Can","VMC"],"legalName":"VMC Immigration Services","description":"CICC-regulated immigration consulting firm. Licensed RCICs specializing in Express Entry, all PNP streams, LMIA, work permits, study permits, spousal sponsorship, refusals, and citizenship. Serving all of Canada from our Brampton, Ontario office.","founder":{"@type":"Person","name":"Sanjay Singh Kumar","jobTitle":"Regulated Canadian Immigration Consultant (RCIC)","identifier":"RCIC R705959","memberOf":{"@type":"Organization","name":"College of Immigration and Citizenship Consultants (CICC)"}},"url":"https://visamastercanada.com","logo":{"@type":"ImageObject","url":"https://visamastercanada.com/logos/vmc-logo.svg"},"image":"https://visamastercanada.com/opengraph-image","telephone":"+16473953471","email":"info@visamastercanada.com","priceRange":"$$","currenciesAccepted":"CAD","paymentAccepted":"Credit Card, Debit Card, Bank Transfer","address":{"@type":"PostalAddress","streetAddress":"83 Kennedy Rd S Unit 16","addressLocality":"Brampton","addressRegion":"ON","postalCode":"L6W 3P3","addressCountry":"CA"},"geo":{"@type":"GeoCoordinates","latitude":43.6956,"longitude":-79.7596},"openingHoursSpecification":[{"@type":"OpeningHoursSpecification","dayOfWeek":["Monday","Tuesday","Wednesday","Thursday","Friday"],"opens":"09:00","closes":"18:00"},{"@type":"OpeningHoursSpecification","dayOfWeek":"Saturday","opens":"10:00","closes":"16:00"}],"areaServed":{"@type":"Country","name":"Canada"},"hasMap":"https://maps.google.com/?q=83+Kennedy+Rd+S,+Brampton,+ON","sameAs":["https://facebook.com/VisaMasterCan","https://linkedin.com/company/visamastercan","https://instagram.com/visamastercanada"],"serviceType":["Express Entry Immigration Consulting","Provincial Nominee Program (PNP) Consulting","Work Permit Application","Study Permit Application","Spousal Sponsorship","LMIA Processing","Visa Refusal Appeals","Citizenship Application","Super Visa Application"]}
```

```json
{"@context":"https://schema.org","@graph":[{"@type":"Service","@id":"https://visamastercanada.com/immigration/super-visa#service","name":"Canada Super Visa Services","description":"Licensed RCIC preparation of Super Visa applications for parents and grandparents - LICO verification, insurance guidance, invitation letters, and full IRCC submission.","areaServed":"Canada","serviceType":"Immigration Consulting"},{"@type":"FAQPage","mainEntity":[{"@type":"Question","name":"Who is eligible for a Super Visa?","acceptedAnswer":{"@type":"Answer","text":"Parents and grandparents of Canadian citizens or permanent residents. The child or grandchild in Canada must meet the minimum income (LICO) and provide an invitation. The applicant needs medical insurance of at least $100,000 CAD from a Canadian insurer."}},{"@type":"Question","name":"How much does Super Visa insurance cost?","acceptedAnswer":{"@type":"Answer","text":"Costs vary by age, health, and coverage period. Canadian insurers offer Super Visa-compliant policies. We can refer you to insurance providers; we do not sell insurance."}},{"@type":"Question","name":"How long does Super Visa processing take in 2026?","acceptedAnswer":{"@type":"Answer","text":"Processing times vary by visa office - often roughly 4-8 weeks for complete files, but always check IRCC's current processing times. We help you prepare a complete application to avoid delays."}},{"@type":"Question","name":"Can I extend my stay on a Super Visa?","acceptedAnswer":{"@type":"Answer","text":"A Super Visa allows stays of up to 5 years per entry. You may apply for a Visitor Record to extend your stay before your status expires."}},{"@type":"Question","name":"What is the difference between Super Visa and a regular visitor visa?","acceptedAnswer":{"@type":"Answer","text":"Super Visa allows up to 5 years per entry and up to 10 years validity, with mandatory medical insurance and host LICO. A regular visitor visa typically allows shorter stays and does not require the same insurance framework. Super Visa is only for parents and grandparents of Canadian citizens or PRs."}},{"@type":"Question","name":"Can both parents apply for a Super Visa at the same time?","acceptedAnswer":{"@type":"Answer","text":"Yes. Both parents can apply for their Super Visas simultaneously - either together in a single application package or separately. Each parent needs their own Super Visa and their own Canadian health insurance policy. We recommend applying together to streamline the process. Both parents are included in the same host invitation letter."}},{"@type":"Question","name":"What if my Super Visa was refused?","acceptedAnswer":{"@type":"Answer","text":"We analyze refusal letters and addresses officer concerns - often income proof, insurance, or ties. We prepare stronger reapplications and can advise on PGP or other options."}}]},{"@type":"BreadcrumbList","itemListElement":[{"@type":"ListItem","position":1,"name":"Home","item":"https://visamastercanada.com"},{"@type":"ListItem","position":2,"name":"Immigration","item":"https://visamastercanada.com/immigration"},{"@type":"ListItem","position":3,"name":"Super Visa","item":"https://visamastercanada.com/immigration/super-visa"}]}]}
```

```json
{"@context":"https://schema.org","@type":"BreadcrumbList","itemListElement":[{"@type":"ListItem","position":1,"name":"Home","item":"https://visamastercanada.com"},{"@type":"ListItem","position":2,"name":"Immigration","item":"https://visamastercanada.com/immigration"},{"@type":"ListItem","position":3,"name":"Super Visa"}]}
```
