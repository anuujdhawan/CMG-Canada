# Spousal Sponsorship Canada 2026: Step-by-Step Guide

> **Source URL:** https://visamastercanada.com/blog/spousal-sponsorship-canada-guide-2026
> **Last modified:** 2026-02-05T00:00:00.000Z
> **Sitemap priority:** 0.8
> **Status:** ✅ Unique English content (processed)

---

## SEO Metadata

- **Title tag:** Spousal Sponsorship Canada 2026: Step-by-Step Guide
- **Meta description:** Spousal and partner sponsorship for Canadian PR in 2026: inland vs outland, required documents, relationship evidence, open work permit, and processing times.
- **Meta keywords:** (none)
- **Canonical URL:** https://visamastercanada.com/blog/spousal-sponsorship-canada-guide-2026
- **OG title:** Spousal Sponsorship Canada 2026: Step-by-Step Guide
- **OG description:** Spousal and partner sponsorship for Canadian PR in 2026: inland vs outland, required documents, relationship evidence, open work permit, and processing times.
- **Robots:** index, follow

## Heading Outline

- # Spousal Sponsorship Canada 2025-2026: Complete Step-by-Step Guide
- ## Who Can Sponsor?
- ## Inland vs Outland: Key Differences
- ## The Most Important Documents: Relationship Evidence
- ## Common-Law Sponsorship: What You Need
- ## Open Work Permit for the Sponsored Spouse (Inland Only)
- ## Processing Times & Fees
- ## Related Articles
- ### Questions about your specific case?

---

## Hero Section

# Spousal Sponsorship Canada 2025-2026: Complete Step-by-Step Guide

Everything you need to know about sponsoring your spouse or common-law partner for Canadian permanent residence - inland vs outland, documents required, relationship evidence, processing times, and how to avoid refusals.

Spousal sponsorship is one of the most emotionally significant applications in Canadian immigration - it is about reuniting families. It is also one of the most document-intensive and scrutinized application types, because IRCC is specifically looking for evidence that the relationship is genuine.

This guide covers everything: who can sponsor, the difference between inland and outland applications, what documents you need, and the most common mistakes that lead to refusals.

---

## Page Content

## Who Can Sponsor?

To sponsor a spouse or common-law partner, you must be: a Canadian citizen, a Canadian permanent resident, or a person registered under the Indian Act. You must be at least 18 years old, not be in a relationship that would disqualify you from sponsoring (such as sponsoring a second spouse while still married to a previously sponsored spouse within the 3-year bar), not be receiving social assistance (except for disability), and not have been convicted of certain crimes. [IRCC's sponsorship eligibility page](https://www.canada.ca/en/immigration-refugees-citizenship/services/immigrate-canada/family-sponsorship/spouse-partner-children.html) lists the full criteria.

## Inland vs Outland: Key Differences

The biggest decision in spousal sponsorship is whether to apply inland or outland:

| Factor |
| Inland |
| Outland |
| Where is the applicant? |
| In Canada on valid temporary status |
| Outside Canada (or Canada OK) |
| Both |
| Processing time |
| 12-18 months |
| 12 months |
| Open work permit? |
| Yes - can apply simultaneously |
| No |
| Can the sponsored person travel? |
| With caution - maintaining status is critical |
| Yes, freely |
| Where is processed? |
| CPC Mississauga |
| Canadian visa office abroad |

## The Most Important Documents: Relationship Evidence

IRCC officers are trained to identify marriages of convenience. The single most important factor in a spousal sponsorship is proving your relationship is genuine. You need to provide consistent, detailed, and varied evidence. The strongest evidence includes:

- Wedding photos - minimum 20-30, showing family, ceremony, celebrations. Include captions.
- Photos over time - different locations and dates, showing the relationship timeline.
- Communication logs - printed WhatsApp/text conversations, email threads, especially for long-distance periods.
- Travel records - boarding passes, hotel receipts, passport stamps showing visits.
- Joint financial evidence - shared bank accounts, joint insurance, joint lease.
- Letters from family and friends who know you as a couple.
- Evidence of communication with each other's families.
IRCC Interviews

IRCC may schedule an interview for either or both of you, especially for outland applications from countries with higher rates of immigration fraud, or when the relationship evidence is thin. Both you and your partner should be able to answer detailed questions about each other's families, daily routines, how you met, and future plans together.

## Common-Law Sponsorship: What You Need

To sponsor a common-law partner, you must prove 12 continuous months of cohabitation (living together). The strongest evidence is a joint lease or mortgage, joint utility bills, joint bank statements, and any other documents showing a shared address over at least one year. A statutory declaration of common-law union is also required.

## Open Work Permit for the Sponsored Spouse (Inland Only)

If applying inland, you can simultaneously submit an application for an open work permit for your sponsored spouse. This is typically approved in 4-6 months and allows your spouse to work for any Canadian employer while waiting for the PR to be processed. This is a significant financial benefit for families.

## Processing Times & Fees

Government fees total approximately $1,625 CAD (sponsorship fee $1,050 + PR processing fee $570) plus $85 per person for biometrics. Processing times are currently 12 months outland and 12-18 months inland. These times have been fairly consistent since 2023.

VMC Recommendation

Spousal applications have a higher refusal rate than most other immigration pathways because of the relationship evidence requirements. Having a licensed RCIC review your application before submission - especially the relationship evidence package - is the most effective way to prevent a refusal.

Sanjay Singh Kumar

Licensed RCIC · VMC Immigration Services

Sanjay Singh Kumar is a Regulated Canadian Immigration Consultant (RCIC) licensed by the College of Immigration and Citizenship Consultants (CICC). He has guided thousands of clients through Express Entry, PNP, work permits, and family sponsorships.

## Related Articles

Express Entry

Express Entry Canada: Complete Beginner's Guide 2025-2026

Read →

Express Entry

CRS Score Explained: How Points Are Calculated & How to Boost Yours in 2026

Read →

Express Entry

Express Entry Category-Based Selection 2026: How It Works & Who Benefits

Read →

Free Consultation

### Questions about your specific case?

Blog articles give general information. A licensed RCIC can assess your specific situation and give you a personalized strategy.

Quick Links

- → Express Entry overview
- → Latest draw results
- → Processing times
- → Document checklists
- → Free CRS calculator
This article is for general information only and does not constitute legal or immigration advice. Every case is unique - consult a licensed RCIC for advice on your specific situation.

---

## Links & CTAs on this page

| Anchor text | URL |
| --- | --- |
| Skip to main content | https://visamastercanada.com/blog/spousal-sponsorship-canada-guide-2026#main-content |
| Make Payment | https://visamastercanada.com/pay |
| Book Book Consultation | https://visamastercanada.com/book |
| Express Entry Express Entry Canada: Complete Beginner's Guide 2025-2026 Read → | https://visamastercanada.com/blog/express-entry-beginners-guide-2026 |
| Express Entry CRS Score Explained: How Points Are Calculated & How to Boost Yours in 2026 Read → | https://visamastercanada.com/blog/express-entry-crs-score-explained |
| Express Entry Express Entry Category-Based Selection 2026: How It Works & Who Benefits Read → | https://visamastercanada.com/blog/express-entry-category-based-selection-2026 |
| 📅 Book Free Consultation | https://visamastercanada.com/book |
| → Express Entry overview | https://visamastercanada.com/immigration/express-entry |
| → Latest draw results | https://visamastercanada.com/draw-results |
| → Processing times | https://visamastercanada.com/resources/processing-times |
| → Document checklists | https://visamastercanada.com/resources/document-checklist |
| → Free CRS calculator | https://visamastercanada.com/tools/crs-calculator |

---

## Image Alt Texts

- Licensed Regulated Canadian Immigration Consultants - Brampton, GTA & Canada-wide

---

## Structured Data (JSON-LD)

```json
{"@context":"https://schema.org","@type":"ProfessionalService","name":"VMC Immigration Services","alternateName":["Visa Master Canada","Visa Master Can","VMC"],"legalName":"VMC Immigration Services","description":"CICC-regulated immigration consulting firm. Licensed RCICs specializing in Express Entry, all PNP streams, LMIA, work permits, study permits, spousal sponsorship, refusals, and citizenship. Serving all of Canada from our Brampton, Ontario office.","founder":{"@type":"Person","name":"Sanjay Singh Kumar","jobTitle":"Regulated Canadian Immigration Consultant (RCIC)","identifier":"RCIC R705959","memberOf":{"@type":"Organization","name":"College of Immigration and Citizenship Consultants (CICC)"}},"url":"https://visamastercanada.com","logo":{"@type":"ImageObject","url":"https://visamastercanada.com/logos/vmc-logo.svg"},"image":"https://visamastercanada.com/opengraph-image","telephone":"+16473953471","email":"info@visamastercanada.com","priceRange":"$$","currenciesAccepted":"CAD","paymentAccepted":"Credit Card, Debit Card, Bank Transfer","address":{"@type":"PostalAddress","streetAddress":"83 Kennedy Rd S Unit 16","addressLocality":"Brampton","addressRegion":"ON","postalCode":"L6W 3P3","addressCountry":"CA"},"geo":{"@type":"GeoCoordinates","latitude":43.6956,"longitude":-79.7596},"openingHoursSpecification":[{"@type":"OpeningHoursSpecification","dayOfWeek":["Monday","Tuesday","Wednesday","Thursday","Friday"],"opens":"09:00","closes":"18:00"},{"@type":"OpeningHoursSpecification","dayOfWeek":"Saturday","opens":"10:00","closes":"16:00"}],"areaServed":{"@type":"Country","name":"Canada"},"hasMap":"https://maps.google.com/?q=83+Kennedy+Rd+S,+Brampton,+ON","sameAs":["https://facebook.com/VisaMasterCan","https://linkedin.com/company/visamastercan","https://instagram.com/visamastercanada"],"serviceType":["Express Entry Immigration Consulting","Provincial Nominee Program (PNP) Consulting","Work Permit Application","Study Permit Application","Spousal Sponsorship","LMIA Processing","Visa Refusal Appeals","Citizenship Application","Super Visa Application"]}
```

```json
{"@context":"https://schema.org","@type":"Article","headline":"Spousal Sponsorship Canada 2025-2026: Complete Step-by-Step Guide","description":"Spousal and partner sponsorship for Canadian PR in 2026: inland vs outland, required documents, relationship evidence, open work permit, and processing times.","datePublished":"2026-02-05","author":{"@type":"Person","name":"Sanjay Singh Kumar"},"publisher":{"@type":"Organization","name":"VMC Immigration Services","url":"https://visamastercanada.com"},"url":"https://visamastercanada.com/blog/spousal-sponsorship-canada-guide-2026"}
```

```json
{"@context":"https://schema.org","@type":"BreadcrumbList","itemListElement":[{"@type":"ListItem","position":1,"name":"Home","item":"https://visamastercanada.com"},{"@type":"ListItem","position":2,"name":"Blog","item":"https://visamastercanada.com/blog"},{"@type":"ListItem","position":3,"name":"Spousal Sponsorship Canada 2025-2026: Complete Step-by-Step Guide","item":"https://visamastercanada.com/blog/spousal-sponsorship-canada-guide-2026"}]}
```
