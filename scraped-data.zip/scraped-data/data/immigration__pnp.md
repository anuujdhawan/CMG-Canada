# Provincial Nominee Program (PNP) Canada 2026 | All 10 Provinces | Licensed RCIC

> **Source URL:** https://visamastercanada.com/immigration/pnp
> **Last modified:** 2026-08-13T16:43:55.760Z
> **Sitemap priority:** 0.9
> **Status:** ✅ Unique English content (processed)

---

## SEO Metadata

- **Title tag:** Provincial Nominee Program (PNP) Canada 2026 | All 10 Provinces | Licensed RCIC
- **Meta description:** PNP Canada 2026 - 91,500 PR admissions nationally across OINP, BC PNP, AAIP, SINP, MPNP and Atlantic provinces. Earn +600 CRS via Enhanced PNP. Licensed RCIC. Free assessment.
- **Meta keywords:** (none)
- **Canonical URL:** https://visamastercanada.com/immigration/pnp
- **OG title:** Canada PNP 2026 - 91,500 PR Admissions | Find Your Province | Licensed RCIC
- **OG description:** Compare all 10 provincial nominee programs. +600 CRS boost via Enhanced PNP. Our licensed RCICs assess your full profile and find the best provincial match.
- **Robots:** index, follow

## Heading Outline

- # Provincial Nominee Program 2026 - 91,500 PR Admissions. Find Your Province.
- ## Two Routes to Canadian PR Through a Province
- ### Enhanced PNP - Through Express Entry
- ### Base PNP - Direct Federal Application
- ## PNP Programs by Province - 2026 Allocations
- ### British Columbia
- ### Alberta
- ### Saskatchewan
- ### Manitoba
- ### Ontario
- ### Nova Scotia
- ### New Brunswick
- ### PEI
- ### Newfoundland
- ### Northern Programs
- ### Not Sure Which Province Matches Your Profile?
- ## PNP Streams That Don't Require a Job Offer
- ### Ontario OINP - Self-Employed Physicians
- ### BC PNP - Express Entry BC
- ### Saskatchewan - Priority Sectors
- ### Manitoba - Human Capital Pathway
- ## PNP When Your CRS Is Too Low for Express Entry
- ### Alberta - Opportunity Stream
- ### Saskatchewan - Capped & Other Sectors
- ### Atlantic Provinces - AIP
- ## How to Get a Provincial Nomination - Step by Step
- ### Profile & Province Assessment
- ### Build or Optimize Express Entry Profile
- ### Provincial EOI or Registration
- ### Nomination Application - Meet the Deadline
- ### Federal PR Application
- ## Why PNP Applicants Choose VMC
- ### Licensed RCICs
- ### All 10 Provinces
- ### Province Matching
- ### Deadline Management
- ### Low CRS Specialists
- ### Canada-Wide + International
- ## Find Your Best Province - Free Assessment
- ## Related

---

## Hero Section

# Provincial Nominee Program 2026 - 91,500 PR Admissions. Find Your Province.

Canada targets 91,500 PNP admissions nationally in 2026 - up 66% from 2025. With 80+ active streams across 10 provinces, PNP is the most flexible route to Canadian PR. A provincial nomination adds +600 CRS points — in recent draws, well above every published federal cutoff. Our team's licensed RCICs match your profile to the highest-probability province.

2026 snapshot

91.5K

PR admissions

+600

CRS boost

80+

Streams

~6 mo

EE PR target

Browse provinces

- → British Columbia
- → Alberta
- → Saskatchewan
- → Manitoba
- → Ontario
- → Nova Scotia
Need a match fast?

VMC ranks provinces by your NOC, CRS, and ties - then maps deadlines.

● Licensed RCIC · CICC-Regulated R705959 · 1,000+ Cases · 8 Languages · Canada-Wide

---

## Page Content

## Two Routes to Canadian PR Through a Province

### Enhanced PNP - Through Express Entry

Province nominates you → IRCC adds +600 CRS to your Express Entry profile → you receive an ITA in the next draw → federal PR in ~6 months. IRCC's official provincial nominee page explains the federal side of the process.

Flow

Province → +600 CRS → ITA → PR in ~6 months

- ✓ Requires active Express Entry profile (FSW or CEC)
- ✓ +600 CRS — in recent draws, well above every published cutoff
- ✓ Fastest PR route - ~6 months federal processing
- ✓ Available: OINP Workforce Priority, BC EE, AAIP EE, SINP EE, MPNP EE

### Base PNP - Direct Federal Application

Province nominates you → you apply directly to IRCC → PR decision in ~18 months. No Express Entry profile needed.

Flow

Province → IRCC Direct → PR in ~18 months

- ✓ No Express Entry profile required
- ✓ Useful for lower CRS or non-EE occupations
- ✓ Some streams only available as Base PNP
- ✓ Longer but still a valid PR pathway

## PNP Programs by Province - 2026 Allocations

Canada targets 91,500 PNP admissions nationally in 2026 - up 66% from 2025. Click your target province to see every stream, requirement, and draw pattern.

### British Columbia

Top streams

- • Skills Immigration (SIRS)
- • Express Entry BC
- • Entrepreneur
Key: Points-based SIRS + weekly draws

Tech & healthcare priority · $62+/hr wage boost

### Alberta

Top streams

- • Opportunity Stream
- • Express Entry (Tech/Healthcare)
- • Tourism & Hospitality
- • Rural Renewal
- • Dedicated Healthcare
Key: 5-6 draws/month · EOI min score 57+

Largest draw frequency in Canada

### Saskatchewan

Top streams

- • Priority Sectors (open)
- • Capped Sectors (6 windows/year)
Key: 3-tier system · Healthcare & tech apply anytime

Major 2026 restructuring · PGWP restrictions apply

### Manitoba

Top streams

- • Skilled Worker in Manitoba
- • Skilled Worker Overseas
- • International Education
Key: Community connection valued

Ties to Manitoba = higher chance

### Ontario

Top streams

- • Workforce Priority - Job Offer (TEER 0-5)
- • Workforce Priority - Self-Employed Physicians
- • EOI portal reopening summer 2026
Key: New Ontario Workforce Priority stream (Jun 26, 2026)

8 legacy streams closed - EOI portal closed, reopen expected summer 2026

### Nova Scotia

Top streams

- • Nova Scotia: Express Entry
- • Skilled Worker
- • Nova Scotia Graduate
- • Entrepreneur
- • AIP
Key: Healthcare workers prioritized

Atlantic Immigration Program available

### New Brunswick

Top streams

- • Express Entry NB
- • Skilled Worker
- • Critical Worker
- • AIP
Key: Community interest letter required

Genuine NB connection needed

### PEI

Top streams

- • Express Entry PEI
- • Labour Impact
- • Critical Worker
- • Business Impact
- • AIP
Key: Small allocation - targeted draws

AIP often better option

### Newfoundland

Top streams

- • Priority Skills NL
- • Express Entry NL
- • International Graduate
- • AIP
Key: Healthcare & skilled trades priority

Atlantic Immigration Program available

### Northern Programs

Top streams

- • Yukon Skilled Worker
- • Yukon EE
- • NWT BNCP
- • Community Pilot
Key: Employer support usually required

Strong community ties essential

### Not Sure Which Province Matches Your Profile?

VMC assesses your NOC, language scores, CRS, education, and any ties to Canada - then identifies the top 2-3 provinces where you have the highest probability of receiving an invitation in 2026.

## PNP Streams That Don't Require a Job Offer

You don't always need a Canadian employer. These streams select based on your Express Entry profile, occupation, or education - no job offer required.

### Ontario OINP - Self-Employed Physicians

The only job-offer-free route into Ontario's new Workforce Priority stream (launched June 26, 2026): OHIP billing number + CPSO good standing. EOI portal temporarily closed - expected to reopen later summer 2026. Get assessment-ready now.

### BC PNP - Express Entry BC

BC nominates Express Entry candidates in targeted tech, health, and trades occupations. High-wage ($62+/hr) or points-based (135+ SIRS). Weekly draws in 2026.

### Saskatchewan - Priority Sectors

Workers in healthcare, agriculture, mining, manufacturing, energy, or tech can apply from overseas with no intake window restriction. No 6-month work permit rule.

### Manitoba - Human Capital Pathway

MPNP draws Express Entry profiles of candidates who have declared Manitoba as their preferred destination. No job offer required for some draws.

## PNP When Your CRS Is Too Low for Express Entry

Federal Express Entry draws often cut off at 480-500+. PNP is designed for skilled applicants who are competitive provincially but not federally - CRS scores as low as 300 have received PNP nominations.

### Alberta - Opportunity Stream

AAIP's largest stream. Currently drawing with EOI minimum scores of 57 (out of ~100). For workers already in Alberta on a work permit. 28,000+ in the pool - apply early.

### Saskatchewan - Capped & Other Sectors

Workers in capped sectors (hospitality, trucking, retail) can apply during 6 intake windows/year. Some draws at very accessible score thresholds.

### Atlantic Provinces - AIP

Atlantic Immigration Program is employer-driven - your CRS score doesn't matter. If an Atlantic employer supports you, you can get nominated regardless of Express Entry ranking.

## How to Get a Provincial Nomination - Step by Step

### Profile & Province Assessment

VMC analyzes your NOC, education, language scores, CRS, work experience, and any Canada ties. VMC identifies top 2-3 provincial matches and ranks them by probability of invitation.

### Build or Optimize Express Entry Profile

For enhanced PNP, you need an active Express Entry profile. VMC creates your profile, selects the best NOC, and maximizes your CRS before province submission.

### Provincial EOI or Registration

BC uses SIRS registration. Ontario uses Express Entry pool + NOI. Alberta uses EOI portal. Each province has a different system - VMC submits to the right one and monitors draws.

### Nomination Application - Meet the Deadline

Once invited by the province (ITA or NOI), you typically have 30-45 days to submit your full nomination application. VMC prepares every document, form, and letter - nothing missed, nothing late.

### Federal PR Application

After provincial nomination: Enhanced PNP → +600 CRS → ITA → PR in ~6 months. Base PNP → apply directly to IRCC → PR in ~18 months. VMC manages both.

## Why PNP Applicants Choose VMC

### Licensed RCICs

CICC regulated. PNP, Express Entry, and federal PR - all in-house with accountable professional advice. Confirm any licence on the CICC register.

### All 10 Provinces

VMC monitors streams across every province - not just Ontario. Alberta, BC, Saskatchewan, Atlantic - wherever your best match is.

### Province Matching

VMC identifies which province has the highest probability of nomination for your specific NOC, CRS, language, and education profile.

### Deadline Management

Provincial nomination deadlines are strict - 30 to 45 days from invitation. VMC tracks every deadline and submits complete packages.

### Low CRS Specialists

PNP is ideal for CRS under 450. VMC actively identifies provinces drawing at your score range and advises on timing.

### Canada-Wide + International

Applicants in Canada and abroad - same licensed team, virtual consultations.

- What is the Provincial Nominee Program?
- How long does PNP take from nomination to PR?
- Can I apply to multiple provinces at once?
Still have questions? Our licensed RCICs answer within 24 hours.

## Find Your Best Province - Free Assessment

Our team's licensed RCICs compare your profile against all active 2026 PNP streams and recommend the highest-probability pathway.

## Related

---

## Links & CTAs on this page

| Anchor text | URL |
| --- | --- |
| Skip to main content | https://visamastercanada.com/immigration/pnp#main-content |
| Make Payment | https://visamastercanada.com/pay |
| Book Book Consultation | https://visamastercanada.com/book |
| Home | https://visamastercanada.com/ |
| Immigration | https://visamastercanada.com/immigration |
| Get Province Matching → | https://visamastercanada.com/book |
| Check My Eligibility | https://visamastercanada.com/tools |
| (647) 395-3471 | tel:+16473953471 |
| → British Columbia | https://visamastercanada.com/immigration/pnp/british-columbia |
| → Alberta | https://visamastercanada.com/immigration/pnp/alberta |
| → Saskatchewan | https://visamastercanada.com/immigration/pnp/saskatchewan |
| → Manitoba | https://visamastercanada.com/immigration/pnp/manitoba |
| → Ontario | https://visamastercanada.com/immigration/pnp/ontario |
| → Nova Scotia | https://visamastercanada.com/immigration/pnp/nova-scotia |
| Book assessment → | https://visamastercanada.com/book |
| British Columbia 5,254 spaces Top streams • Skills Immigration (SIRS) • Express Entry BC • Entrepreneur Key: Points-based SIRS + weekly draws Tech & healthcare priority · $62+/hr wage boost Explore | https://visamastercanada.com/immigration/pnp/british-columbia |
| Alberta 6,403 spaces Top streams • Opportunity Stream • Express Entry (Tech/Healthcare) • Tourism & Hospitality • Rural Renewal • Dedicated Healthcare Key: 5-6 draws/month · EOI min score 57+ Largest draw frequency in Canada Explore | https://visamastercanada.com/immigration/pnp/alberta |
| Saskatchewan 4,761 spaces Top streams • Priority Sectors (open) • Capped Sectors (6 windows/year) Key: 3-tier system · Healthcare & tech apply anytime Major 2026 restructuring · PGWP restrictions apply Explore | https://visamastercanada.com/immigration/pnp/saskatchewan |
| Manitoba Continuous Top streams • Skilled Worker in Manitoba • Skilled Worker Overseas • International Education Key: Community connection valued Ties to Manitoba = higher chance Explore | https://visamastercanada.com/immigration/pnp/manitoba |
| Ontario 14,119 spaces Top streams • Workforce Priority - Job Offer (TEER 0-5) • Workforce Priority - Self-Employed Physicians • EOI portal reopening summer 2026 Key: New Ontario Workforce Priority stream (Jun 26, 2026) 8 legacy streams closed - EOI portal closed, reopen expected summer 2026 Explore | https://visamastercanada.com/immigration/pnp/ontario |
| Nova Scotia AIP + NSNP Top streams • Nova Scotia: Express Entry • Skilled Worker • Nova Scotia Graduate • Entrepreneur • AIP Key: Healthcare workers prioritized Atlantic Immigration Program available Explore | https://visamastercanada.com/immigration/pnp/nova-scotia |
| New Brunswick AIP + NBPNP Top streams • Express Entry NB • Skilled Worker • Critical Worker • AIP Key: Community interest letter required Genuine NB connection needed Explore | https://visamastercanada.com/immigration/pnp/new-brunswick |
| PEI Targeted draws Top streams • Express Entry PEI • Labour Impact • Critical Worker • Business Impact • AIP Key: Small allocation - targeted draws AIP often better option Explore | https://visamastercanada.com/immigration/pnp/pei |
| Newfoundland NLPNP + AIP Top streams • Priority Skills NL • Express Entry NL • International Graduate • AIP Key: Healthcare & skilled trades priority Atlantic Immigration Program available Explore | https://visamastercanada.com/immigration/pnp/newfoundland |
| Northern Programs Territory streams Top streams • Yukon Skilled Worker • Yukon EE • NWT BNCP • Community Pilot Key: Employer support usually required Strong community ties essential Explore | https://visamastercanada.com/immigration/pnp/northern |
| Book Province Matching Assessment → | https://visamastercanada.com/book |
| Call (647) 395-3471 | tel:+16473953471 |
| Ontario OINP → | https://visamastercanada.com/immigration/pnp/ontario |
| Manitoba MPNP → | https://visamastercanada.com/immigration/pnp/british-columbia |
| Saskatchewan SINP → | https://visamastercanada.com/immigration/pnp/saskatchewan |
| Manitoba MPNP → | https://visamastercanada.com/immigration/pnp/manitoba |
| Alberta → | https://visamastercanada.com/immigration/pnp/alberta |
| Saskatchewan → | https://visamastercanada.com/immigration/pnp/saskatchewan |
| Atlantic Provinces → | https://visamastercanada.com/immigration/pnp/nova-scotia |
| Book Free Consultation | https://visamastercanada.com/contact |
| Book Free Assessment → | https://visamastercanada.com/book |
| Use Free Tools | https://visamastercanada.com/tools |
| Express Entry → | https://visamastercanada.com/immigration/express-entry |
| Work Permit → | https://visamastercanada.com/immigration/work-permit |
| Study Permit → | https://visamastercanada.com/immigration/study-permit |
| Family Sponsorship → | https://visamastercanada.com/immigration/family-sponsorship |

---

## Image Alt Texts

- Licensed Regulated Canadian Immigration Consultants - Brampton, GTA & Canada-wide

---

## Structured Data (JSON-LD)

```json
{"@context":"https://schema.org","@type":"ProfessionalService","name":"VMC Immigration Services","alternateName":["Visa Master Canada","Visa Master Can","VMC"],"legalName":"VMC Immigration Services","description":"CICC-regulated immigration consulting firm. Licensed RCICs specializing in Express Entry, all PNP streams, LMIA, work permits, study permits, spousal sponsorship, refusals, and citizenship. Serving all of Canada from our Brampton, Ontario office.","founder":{"@type":"Person","name":"Sanjay Singh Kumar","jobTitle":"Regulated Canadian Immigration Consultant (RCIC)","identifier":"RCIC R705959","memberOf":{"@type":"Organization","name":"College of Immigration and Citizenship Consultants (CICC)"}},"url":"https://visamastercanada.com","logo":{"@type":"ImageObject","url":"https://visamastercanada.com/logos/vmc-logo.svg"},"image":"https://visamastercanada.com/opengraph-image","telephone":"+16473953471","email":"info@visamastercanada.com","priceRange":"$$","currenciesAccepted":"CAD","paymentAccepted":"Credit Card, Debit Card, Bank Transfer","address":{"@type":"PostalAddress","streetAddress":"83 Kennedy Rd S Unit 16","addressLocality":"Brampton","addressRegion":"ON","postalCode":"L6W 3P3","addressCountry":"CA"},"geo":{"@type":"GeoCoordinates","latitude":43.6956,"longitude":-79.7596},"openingHoursSpecification":[{"@type":"OpeningHoursSpecification","dayOfWeek":["Monday","Tuesday","Wednesday","Thursday","Friday"],"opens":"09:00","closes":"18:00"},{"@type":"OpeningHoursSpecification","dayOfWeek":"Saturday","opens":"10:00","closes":"16:00"}],"areaServed":{"@type":"Country","name":"Canada"},"hasMap":"https://maps.google.com/?q=83+Kennedy+Rd+S,+Brampton,+ON","sameAs":["https://facebook.com/VisaMasterCan","https://linkedin.com/company/visamastercan","https://instagram.com/visamastercanada"],"serviceType":["Express Entry Immigration Consulting","Provincial Nominee Program (PNP) Consulting","Work Permit Application","Study Permit Application","Spousal Sponsorship","LMIA Processing","Visa Refusal Appeals","Citizenship Application","Super Visa Application"]}
```

```json
{"@context":"https://schema.org","@graph":[{"@type":"WebPage","@id":"https://visamastercanada.com/immigration/pnp#webpage","url":"https://visamastercanada.com/immigration/pnp","name":"Provincial Nominee Program Canada 2026","description":"Compare all 10 provincial nominee programs. 91,500 PNP admissions nationally in 2026. +600 CRS via Enhanced PNP. Licensed RCIC province matching.","isPartOf":{"@type":"WebSite","name":"Licensed Regulated Canadian Immigration Consultants","url":"https://visamastercanada.com"}},{"@type":"Service","@id":"https://visamastercanada.com/immigration/pnp#service","name":"VMC Provincial Nominee Program Assessment","description":"Licensed RCIC PNP matching across all Canadian provinces - Express Entry alignment, stream selection, EOI submission, and nomination application support.","areaServed":"Canada","serviceType":"Immigration Consulting"},{"@type":"FAQPage","mainEntity":[{"@type":"Question","name":"What is the Provincial Nominee Program?","acceptedAnswer":{"@type":"Answer","text":"The PNP allows Canadian provinces and territories to nominate individuals for permanent residence based on their own labour market needs. Unlike Express Entry (which is purely federal), PNP lets provinces identify the workers they need. In 2026, Canada targets 91,500 PNP admissions nationally - up 66% from 55,000 in 2025. There are 10 provinces with PNP programs and 80+ active streams. A provincial nomination means a province has vouched for you as someone who will contribute to their economy and community."}},{"@type":"Question","name":"How long does PNP take from nomination to PR?","acceptedAnswer":{"@type":"Answer","text":"It depends on whether your stream is Enhanced (Express Entry-aligned) or Base. Enhanced PNP: once nominated, you receive +600 CRS points, get an ITA at the next Express Entry draw, and federal PR takes approximately 6 months. Base PNP: you apply directly to IRCC and PR typically takes 18 months or more. VMC advises on the fastest route for your situation."}},{"@type":"Question","name":"Can I apply to multiple provinces at once?","acceptedAnswer":{"@type":"Answer","text":"Yes. There is no restriction on holding active registrations or EOIs in multiple provincial systems simultaneously. Many of our clients have active profiles in 2-3 provinces at once. VMC manages all submissions and advises when an invitation arrives which to pursue based on your goals."}},{"@type":"Question","name":"What is an Enhanced PNP nomination?","acceptedAnswer":{"@type":"Answer","text":"An Enhanced PNP nomination is a provincial nomination that is processed through Canada's federal Express Entry system. When a province nominates you through an Enhanced stream, IRCC automatically adds 600 CRS points to your Express Entry profile. Since most Express Entry draws have CRS cutoffs of 480-500, the +600 points place your score well above every recently published cutoff — though IRCC sets the cutoff independently each round. This means you go from the Express Entry pool to a PR application in approximately 6 months from nomination."}},{"@type":"Question","name":"What is a Base PNP and who should use it?","acceptedAnswer":{"@type":"Answer","text":"A Base PNP nomination means you apply directly to IRCC for PR outside the Express Entry system. Processing takes approximately 18 months instead of 6. Base PNP is useful when: you don't have an Express Entry profile (no NOC TEER 0-3 work experience), your occupation is not in the Express Entry system, or you qualify for a provincial stream that only operates as Base PNP. VMC identifies whether Enhanced or Base is available for your specific stream and province."}},{"@type":"Question","name":"Which PNP streams don't require a job offer?","acceptedAnswer":{"@type":"Answer","text":"Several major streams don't require a job offer: BC PNP Express Entry BC draws high-wage workers and tech professionals without requiring a job offer in some targeted draws. Saskatchewan's Priority Sector streams for healthcare, agriculture, mining, energy, and tech workers - including overseas applicants - don't require a job offer. Manitoba's Human Capital Pathway draws Express Entry candidates who've declared Manitoba as preferred province. Ontario's new Workforce Priority stream (launched June 26, 2026) is job-offer-based for every NOC TEER level (0-5) - the only route into it that does not require a job offer is the Self-Employed Physicians pathway (OHIP billing number + CPSO good standing). VMC identifies no-job-offer options for your NOC."}},{"@type":"Question","name":"Can I get PNP with a low CRS score?","acceptedAnswer":{"@type":"Answer","text":"Yes - PNP is specifically designed for applicants who are competitive provincially but struggle in federal Express Entry draws. Alberta's Opportunity Stream has drawn with EOI minimums as low as 57 (out of ~100 - a different scale from CRS). Saskatchewan draws in capped sectors at accessible thresholds. Atlantic provinces via AIP don't use CRS at all - employer support is what matters. CRS scores of 300-400 have successfully obtained PNP nominations through the right provincial stream. VMC identifies which provinces have current draws at your score level."}},{"@type":"Question","name":"How does PNP nomination work step by step with VMC?","acceptedAnswer":{"@type":"Answer","text":"VMC analyzes your profile, optimizes Express Entry for Enhanced streams, submits the correct provincial EOI or registration, prepares your full nomination application within the deadline, then manages your federal PR - either +600 CRS and ITA for Enhanced, or direct IRCC for Base PNP."}},{"@type":"Question","name":"What major PNP changes happened in 2026?","acceptedAnswer":{"@type":"Answer","text":"2026 is one of the most significant years for PNP in Canada's immigration history: (1) National target jumped to 91,500 PNP admissions - up 66% from 55,000 in 2025. (2) Ontario overhauled OINP in two steps: the regulatory framework for all 9 legacy categories was repealed May 30, 2026, then on June 26, 2026 the 8 active streams were operationally closed and replaced by a single new Ontario Workforce Priority stream (TEER 0-3 and TEER 4-5 pathways, plus Self-Employed Physicians). The EOI portal is currently closed; it is expected to reopen later summer 2026. (3) Saskatchewan restructured SINP into a three-tier priority/capped/other system with intake windows for capped sectors. PGWP and SOWP holders face new restrictions. The Entrepreneur, International Graduate Entrepreneur, and Farm Owner/Operator categories were permanently closed in March 2025. (4) BC raised Skills Immigration fees to $1,750 and introduced dual selection: wage-based ($62+/hr) and points-based (135+ SIRS). Graduate streams remain suspended. (5) Alberta has 6,403 spots with 5-6 draws per month across multiple streams including Accelerated Tech and Healthcare Dedicated pathways. Last verified: June 2026."}}]},{"@type":"BreadcrumbList","itemListElement":[{"@type":"ListItem","position":1,"name":"Home","item":"https://visamastercanada.com"},{"@type":"ListItem","position":2,"name":"Immigration","item":"https://visamastercanada.com/immigration"},{"@type":"ListItem","position":3,"name":"Provincial Nominee Program","item":"https://visamastercanada.com/immigration/pnp"}]}]}
```

```json
{"@context":"https://schema.org","@type":"BreadcrumbList","itemListElement":[{"@type":"ListItem","position":1,"name":"Home","item":"https://visamastercanada.com"},{"@type":"ListItem","position":2,"name":"Immigration","item":"https://visamastercanada.com/immigration"},{"@type":"ListItem","position":3,"name":"Provincial Nominee Program"}]}
```
